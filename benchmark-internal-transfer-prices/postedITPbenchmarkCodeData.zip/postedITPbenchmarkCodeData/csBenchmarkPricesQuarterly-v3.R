# Purpose:	Collate benchmark futures prices, based on various averages of past ASX futures prices
#
# Author:	Christie Smith 	29 July 2020
# 
# INPUTS
#	A CSV file of futures markets prices obtained from the Electricity Authority's Market Analytics team.
#
# OUTPUT
#	benchmarkPrices: Returns a variable (or potentially a CSV file) that contains various benchmark futures prices, 
#	which are various weighted averages of futures prices, where the weights are derived from monthly-zonal load profiles.
# (See csLoadAnalysisITP-v2.R for the derivation of the weights.)
#
# CHANGE-LOG
# v1: Revised to correct mistakes related to the sampling of the futures prices
# v2: Revised to update for Genesis' 23 October 2020 revision to their transfer prices.
# v3: Minor updates to improve readability

# lubridate facilitate some date operations
library(lubridate)

# Note: Only switched to using tidyverse (dplyr) late in the program
library(tidyverse)
library(matrixStats)

##############################################################################
## Program inputs
# instrumentType <- "EA" = EA = Otahuhu Base Load Quartery Futures
# instrumentType <- "EE" = EE = Benmore Base Load Quarterly Futures

instrumentType<-"EA"

# Output file name
fileName<-paste('QuarterlyFuturesBenchmark',today(),'v1.csv', sep='')
baseDir<-'H:/My Documents/D3D4/rCode'
outputDir<-paste0('/csITPOutput/',today())

# Whenever you add an extra 'benchmark price' -- increment numBenchmarks (specifies number of columns of a dataframe that is outputted)
# NB - should not need to amend otherwise
numBenchmarks<-23

# Define the names of the dataframe
# NB -- make sure these names align with variables in tempdf in the loop below
benchmarkNamen<-c('Expiration', 'threeYrAvg41628', 'threeYrAvg11325', 'threeYrAvgQ', 'simpleAverage', 'minPrice', 'maxPrice', 'Q1', 'Q2', 'Q3', 'Q4', 
		'mthAverage4plus', 'Q4plus_1', 'Q4plus_2', 'Q4plus_3', 'Q4plus_4', 'mthAverage4', 'Q41', 'Q42', 'Q43', 'Q44', 'mthAverage456', 'fwdAverage12Q')

# End of program inputs
##############################################################################



## Functions/procedures used below

# Define a function to iterate through an array and conduct element-by-element multiplication of [load] weights and prices, which are then summed
csLoadWeightPrices<-function(loadWeightMatrix,locTimeBenchFY){
# Purpose: Define a simple function to do the required matrix multiplication to that you don't need to repeat the code that multiples "load-weights" and "prices"
# INPUTS:	loadweightMatrix: A load-weight matrix: dimensions numZones by 12, the matrix elements should sum to 1.
#		locTimeBenchFY:  A 'price' array: dimensions: numZones by numMonths by numBnchs by numYears.
# OUTPUTS:	ITPs: numBnchs by numYears matrix of ITPs. ITP[i,ttt] is the internal transfer price for year ttt from benchmark i. 
	dimP<-dim(locTimeBenchFY)
	numZones<-dimP[1]
	numMonths<-dimP[2]
	numBnchs<-dimP[3]
	numYears<-dimP[4]
	ITPs<-matrix(NA,numBnchs,3)
	for (ttt in 1:3){ 
		for (m in 1:numBnchs){
			# Note that sum() sums all the elements in a matrix into a single number (cf. colSums or rowSums)
			# And the * multiplication does element-by-element multiplication (not matrix multiplication)
			ITPs[m,ttt]<-sum(locTimeBenchFY[,,m,ttt]*loadWeightMatrix)
		}
	}
	rownames(ITPs)<-dimnames(locTimeBenchFY)[[3]]
	colnames(ITPs)<-dimnames(locTimeBenchFY)[[4]]
	return(ITPs)	
}

# Define a function to convert dates to a plot-friendly sequence
csDate2mm<-function(ttt){
# Purpose: Define a function to convert dates to a plot-friendly sequence
# INPUT: Monthly date sequence like 2009.08, 2009.09, 2009.10, 2009.11, 2009.12
# OUTPUT: t: Monthly date sequence where 2009+8/12-1/24, 2009+9/12-1/24, etc. so that each element is centered in 1/12
#
t<-floor(ttt)+100*(ttt-floor(ttt))*1/12 - 1/12
return(t)}

## End of functions / beginning of program
##############################################################################


# Go to the first day of April, then go back 1 day to get the last day of March; continue with that sequence -- marries up with expirationDate format in the data
expirationMonths<-seq(as.Date("2017-04-01"), length=20, by="3 month") - 1

# Load 'monthly' futures data -- NB The underlying data is proprietary and cannot be supplied
# To get a sense of this data see REDACTED-Futures Markets Prices 2020-07-09 Settlement price summary.csv
df <- read.csv("h:/my documents/D3D4/rCode/Futures Markets Prices 2020-07-09 Settlement price summary.csv", header=TRUE, fileEncoding="UTF-8-BOM")


# Fix Expiration dates of df
df$Expiration<-as.Date(df$Expiration,tryFormats="%d/%m/%Y")
# Check the formats of df$Expiration 
# df$Expiration[1:10]
df$ExpirationYM<-as.numeric(format(df$Expiration, '%Y.%m'))

# Note: the settlement date (unfortunate terminology) is the date when a contract is bought/sold 
# (in contrast to the expiration date, which is when the contract will pay out; settlement dates thus precede expiration dates)
df$SettlementMonth<-as.Date(df$SettlementMonth,tryFormats="%d/%m/%Y")
df$obsoleteMonthsRemainingToExpiry<-df$MonthsRemainingToExpiry

# In following line +1 because settlement months are beginning of month and Expiration is last-working-day-of-month and we don't want zeroes
df$MonthsRemainingToExpiry<-year(df$Expiration)*12+month(df$Expiration)-year(df$SettlementMonth)*12-month(df$SettlementMonth)+1
# tempy<-data.frame(df$Expiration, df$SettlementMonth, df$MonthsRemainingToExpiry, df$obsoleteMonthsRemainingToExpiry)
# Check the updated MonthsRemainingToExpiry against the obsolete series, etc.
# print(tempy[1:100,])

# Load raw monthly spot data -- for Otahuhu and Benmore
SpotDf <- read.csv("h:/my documents/D3D4/rCode/Spot prices - Otahuhu Benmore -- Wholesale_price_summary_20200813154254 (1).csv", header=TRUE, fileEncoding="UTF-8-BOM", nrows=120)

df$SettlementMonth<-as.Date(df$SettlementMonth,tryFormats="%d/%m/%Y")
# Check the formats of df$SettlmentMonths 
# df$SettlementMonth[1:10]

# Extract just the month from the dates
SettlementMonth<-format(df$SettlementMonth, "%m")
SettlementMonth<-as.numeric(SettlementMonth)
df$settlementMonthYM<-as.numeric(format(df$SettlementMonth, '%Y.%m'))

# Check what they look like
# SettlementMonth[1:10]

# Select contract type (eg EB=strips)
contractFamily<-df[df$Instrument==instrumentType,]

# Pre-define an empty dataframe -- note that numBenchmarks is specifed in the control-variable section
benchmarkPrices <- data.frame(matrix(ncol = numBenchmarks, nrow = 0))
names(benchmarkPrices)<-benchmarkNamen

# Iterate through the Expiration dates in expirationMonths and collate various 'benchmark' averages of futures prices.
for (iii in 1:length(expirationMonths))
{	
	# Pull out the contracts for the four quarters that we're interested in -- for specific expiration dates
	# Note the complicated use of format is to account for the fact that the expiration dates are for the last WORKING day of the month, not necessarily the LAST DAY
	# Arguably, this is a flaw in the way I have defined expirationMonths
	# Note also that expirationMonths is a sequence of quarterly months (analysis based on quarterly futures, not monthlies or strips). 
	# So if expirationMonths[1]=="2017-03-31" expirationMonths[2]=="2017-06-30" and expirationMonths[3]=="2017-09-30".
	tempDF1<-contractFamily[format(expirationMonths[iii],format="%Y.%m")==format(contractFamily$Expiration,format="%Y.%m"),]
	tempDF2<-contractFamily[format(expirationMonths[iii+1],format="%Y.%m")==format(contractFamily$Expiration,format="%Y.%m"),]	
	tempDF3<-contractFamily[format(expirationMonths[iii+2],format="%Y.%m")==format(contractFamily$Expiration,format="%Y.%m"),]	
	tempDF4<-contractFamily[format(expirationMonths[iii+3],format="%Y.%m")==format(contractFamily$Expiration,format="%Y.%m"),]	

	# Define the indexes used to form the benchmark internal transfer price (ITP)
	# Note that expDate is a single number corresponding to the first of four quarterly contracts
	expDate<- as.numeric( format(expirationMonths[iii], '%Y.%m'));	# Specifies date in YYYY.MM format

	# This is akin to averaging the forward curve over three years -- using the forward curve that prevailed 4 months before the expiration date
	fwdSettleDate<-tempDF1$SettlementMonth[tempDF1$MonthsRemainingToExpiry==4]

	# Add three years and take fwd prices whose expiration dates are less than 3 years + expdate
	endQ<-expDate+3
	fwdAverage12Q<-contractFamily$MeanPrice[contractFamily$SettlementMonth==fwdSettleDate & format(contractFamily$Expiration,format="%Y.%m")>=expDate & format(contractFamily$Expiration,format="%Y.%m")<endQ]
	
	# Take the average of a given forward curve -- this is a special case benchmark
	fwdAverage12Q<-mean(fwdAverage12Q)

	# NB -- the four contracts may/can have different sequences of settlementDates

	# Identify MONTHLY separation [hence 'sep'] between settlementDates and expiration 
	# NB -- expDate is the expiration date for the first of the four quarterly contracts! -- Note the code averages only those futures prices that are available in the data set 
	SepMthsIndx1 <-is.element(tempDF1$MonthsRemainingToExpiry, c(4,16,28)) 
	SepMthsIndx2<-is.element(tempDF2$SettlementMonth,tempDF1$SettlementMonth[SepMthsIndx1])
	SepMthsIndx3<-is.element(tempDF3$SettlementMonth,tempDF1$SettlementMonth[SepMthsIndx1])
	SepMthsIndx4<-is.element(tempDF4$SettlementMonth,tempDF1$SettlementMonth[SepMthsIndx1])

	# Check the dates that are being pulled out	
	# tempDF1$SettlementMonth[SepMthsIndx1]
	# tempDF2$SettlementMonth[SepMthsIndx2]
	# tempDF3$SettlementMonth[SepMthsIndx3]
	# tempDF4$SettlementMonth[SepMthsIndx4]

	# tempDF1$MeanPrice[SepMthsIndx1]
	# tempDF2$MeanPrice[SepMthsIndx2]
	# tempDF3$MeanPrice[SepMthsIndx3]
	# tempDF4$MeanPrice[SepMthsIndx4]

	# Pick the settlementMonths that we want to use to form our benchmark ITP -- same settlementMonth for each of the four quarters
	Q1<-mean(tempDF1$MeanPrice[SepMthsIndx1])
	Q2<-mean(tempDF2$MeanPrice[SepMthsIndx2])
	Q3<-mean(tempDF3$MeanPrice[SepMthsIndx3])
	Q4<-mean(tempDF4$MeanPrice[SepMthsIndx4])
	# This is one benchmark
	threeYrAvg41628<-mean(c(Q1,Q2,Q3,Q4), na.rm=TRUE)

	# Select indexes with desired monthly separation -- in this case three quarters, separated by a year
	sepMthsIdx1q<- is.element(tempDF1$MonthsRemainingToExpiry, c(4,5,6,16,17,18,28,29,30))
	sepMthsIdx2q<-is.element(tempDF2$SettlementMonth,tempDF1$SettlementMonth[sepMthsIdx1q])
	sepMthsIdx3q<-is.element(tempDF3$SettlementMonth,tempDF1$SettlementMonth[sepMthsIdx1q])
	sepMthsIdx4q<-is.element(tempDF4$SettlementMonth,tempDF1$SettlementMonth[sepMthsIdx1q])

	Q1q<-mean(tempDF1$MeanPrice[sepMthsIdx1q])
	Q2q<-mean(tempDF2$MeanPrice[sepMthsIdx2q])
	Q3q<-mean(tempDF3$MeanPrice[sepMthsIdx3q])
	Q4q<-mean(tempDF4$MeanPrice[sepMthsIdx4q])
	# This is another benchmark that samples more historic futures prices
	threeYrAvgQ<-mean(c(Q1q,Q2q,Q3q,Q4q), na.rm=TRUE)

	# Check the underlying data being used to form the benchmarks
	#tempDF1$MeanPrice[sepMthsIdx1q]
	#tempDF2$MeanPrice[sepMthsIdx2q]
	#tempDF3$MeanPrice[sepMthsIdx3q]
	#tempDF4$MeanPrice[sepMthsIdx4q]

	# print(c(Q1,Q2,Q3,Q4,threeYrAvg41628))
	# print(c(Q1q,Q2q,Q3q,Q4q,threeYrAvgQ))
	# print('************')

	# Time separation uses all possible futures contracts prior to four months before the expiration date
	sepMthsIdx14plus<- tempDF1$MonthsRemainingToExpiry>=4
	sepMthsIdx24plus<-is.element(tempDF2$SettlementMonth,tempDF1$SettlementMonth[sepMthsIdx14plus])
	sepMthsIdx34plus<-is.element(tempDF3$SettlementMonth,tempDF1$SettlementMonth[sepMthsIdx14plus])
	sepMthsIdx44plus<-is.element(tempDF4$SettlementMonth,tempDF1$SettlementMonth[sepMthsIdx14plus])

	Q4plus_1<-mean(tempDF1$MeanPrice[sepMthsIdx14plus])
	Q4plus_2<-mean(tempDF2$MeanPrice[sepMthsIdx24plus])
	Q4plus_3<-mean(tempDF3$MeanPrice[sepMthsIdx34plus])
	Q4plus_4<-mean(tempDF4$MeanPrice[sepMthsIdx44plus])

	# This is another benchmark
	# Average based on ALL futures prices available 4 months before the expiration data
	mthAverage4plus<-mean(c(Q4plus_1, Q4plus_2, Q4plus_3, Q4plus_4), na.rm=TRUE)

	# The following is excluded from the reported benchmarks -- not akin to a methodology actually used
	# Average based on futures prices available EXACTLY 4 months before the expiration data of the 1st quarterly contract
	sepMthsIdx14<- tempDF1$MonthsRemainingToExpiry==4
	sepMthsIdx24<-is.element(tempDF2$SettlementMonth,tempDF1$SettlementMonth[sepMthsIdx14])
	sepMthsIdx34<-is.element(tempDF3$SettlementMonth,tempDF1$SettlementMonth[sepMthsIdx14])
	sepMthsIdx44<-is.element(tempDF4$SettlementMonth,tempDF1$SettlementMonth[sepMthsIdx14])

	Q4_1<-mean(tempDF1$MeanPrice[sepMthsIdx14])
	Q4_2<-mean(tempDF2$MeanPrice[sepMthsIdx24])
	Q4_3<-mean(tempDF3$MeanPrice[sepMthsIdx34])
	Q4_4<-mean(tempDF4$MeanPrice[sepMthsIdx44])

	# Based on a single months data
	mthAverage4<-mean(c(Q4_1,Q4_2,Q4_3,Q4_4), na.rm=TRUE)

	# Average based on futures prices available 4,5,6 months before the expiration data
	sepMthsIdx1456<- is.element(tempDF1$MonthsRemainingToExpiry, 4:6)
	sepMthsIdx2456<-is.element(tempDF2$SettlementMonth,tempDF1$SettlementMonth[sepMthsIdx1456])
	sepMthsIdx3456<-is.element(tempDF3$SettlementMonth,tempDF1$SettlementMonth[sepMthsIdx1456])
	sepMthsIdx4456<-is.element(tempDF4$SettlementMonth,tempDF1$SettlementMonth[sepMthsIdx1456])

	Q456_1<-mean(tempDF1$MeanPrice[sepMthsIdx1456])
	Q456_2<-mean(tempDF2$MeanPrice[sepMthsIdx2456])
	Q456_3<-mean(tempDF3$MeanPrice[sepMthsIdx3456])
	Q456_4<-mean(tempDF4$MeanPrice[sepMthsIdx4456])

	# This is another benchmark	
	# Based on quarters of prices
	mthAverage456<-mean(c(Q456_1,Q456_2,Q456_3,Q456_4), na.rm=TRUE)

	# Benchmark using futures prices 1,13,25 months in advance
	sepMthsIdx1_11325<- is.element(tempDF1$MonthsRemainingToExpiry, c(1,13,25))
	sepMthsIdx2_11325<-is.element(tempDF2$SettlementMonth,tempDF1$SettlementMonth[sepMthsIdx1_11325])
	sepMthsIdx3_11325<-is.element(tempDF3$SettlementMonth,tempDF1$SettlementMonth[sepMthsIdx1_11325])
	sepMthsIdx4_11325<-is.element(tempDF4$SettlementMonth,tempDF1$SettlementMonth[sepMthsIdx1_11325])

	Q11325_1<-mean(tempDF1$MeanPrice[sepMthsIdx1_11325])
	Q11325_2<-mean(tempDF2$MeanPrice[sepMthsIdx2_11325])
	Q11325_3<-mean(tempDF3$MeanPrice[sepMthsIdx3_11325])
	Q11325_4<-mean(tempDF4$MeanPrice[sepMthsIdx4_11325])

	# Another benchmark	
	# Based on three months separated by a year
	threeYrAvg11325<-mean(c(Q11325_1,Q11325_2,Q11325_3,Q11325_4), na.rm=TRUE)

	# Check some output
	# print(c(tempDF1$MeanPrice[is.element(timeSep1,c(1,13,25))], tempDF2$MeanPrice[is.element(timeSep2,c(1,13,25))], tempDF3$MeanPrice[is.element(timeSep3,c(1,13,25))], tempDF4$MeanPrice[is.element(timeSep4,c(1,13,25))]))

	# Simple average based on all possible prices
	simpleAverage<-(mean(tempDF1$MeanPrice)+mean(tempDF2$MeanPrice)+mean(tempDF3$MeanPrice)+mean(tempDF4$MeanPrice))/4

	# Perfect foresight - minimum price (retail arm's preferred price, buy electricity at minimum futures price)
	minPrice<-(min(tempDF1$MeanPrice)+min(tempDF2$MeanPrice)+min(tempDF3$MeanPrice)+min(tempDF4$MeanPrice))/4 

	# Perfect foresight - max price (generator arm's preferred price, sell electricity at maximum futures price)
	maxPrice<-(max(tempDF1$MeanPrice)+max(tempDF2$MeanPrice)+max(tempDF3$MeanPrice)+max(tempDF4$MeanPrice))/4  
	
	# Note the expiration dates get turned into numeric observations -- days since 1970/01/01. I.e. 1970/1/3, 2 days after the 1970 New Year, corresponds to numeric 3.
	tempdf<-data.frame(cbind(as.numeric(expDate), threeYrAvg41628, threeYrAvg11325, threeYrAvgQ, simpleAverage, minPrice, maxPrice, Q1, Q2, Q3, Q4, 
					mthAverage4plus, Q4plus_1, Q4plus_2, Q4plus_3, Q4plus_4, mthAverage4, Q4_1, Q4_2, Q4_3, Q4_4, mthAverage456, fwdAverage12Q))
	names(tempdf)<-benchmarkNamen

	# Collate benchmark prices (and the expiration date into a dataframe
	benchmarkPrices<-rbind(benchmarkPrices,tempdf);
}


benchmarkNotes<-c('Notes', 
	'The numbers in the benchmarks correspond to the number of months used prior to the expiration date of the 1st (of 4) quarterly contracts.',
	'threeYrAvg41628 is based on contracts 4,16,28 months in advance of expiry of the first quarterly contract.', 
	'threeYrAvg11325 is based on contracts 1,13,25 months in advance of expiry of the first quarterly contract.', 
	'threeYrAvgQ uses futures prices from 4,5,6,16,17,18,28,29,30 in advance of expiry of the first quarterly contract.',
	'simpleAvg is an average of all the futures prices across all settlement dates for the four quarters.',
	'maxPrice uses the maximum prices for all of the four quarters.',
	'minPrice uses the minimum prices for all four quarters.',
	'Q1,Q2,Q3,Q4 are the quarters underpinning threeYrAvg41628 (a simple average of the four).',
	'mthAverage4plus is an average of futures prices 4 OR MORE months before the expiration date of the first quarterly contract.',
	'Q4plus_1,Q4plus_2,Q4plus_3,Q4plus_4 are the quarters underpinning mthAverage4plus.',
	'mthAverage4 is based on the futures 4 months before expiration of the first quarterly contract.',
	'Q41,Q42,Q43,Q44 are the quarters underpinning mthAverage4 (a simple average of the four).',
	'mthAverage456 is based on the quarter of futures contracts, 4,5,6 months before expiration of the first quarterly contract.',
	'fwdAverage12Q is akin to the 12 quarter average of the forward curve that exists fourth months before the first quarter of the financial year.')


## Output table
print('instrumentType = EA = Otahuhu Base Load Quartery Futures')
print('instrumentType = EE = Benmore Base Load Quarterly Futures')
print(instrumentType)
print(benchmarkPrices)

# Set the 'working directory' to receive the output
dir.create(paste0(baseDir,outputDir))
setwd(paste0(baseDir,outputDir))


# Plot the futures
#png(file=paste("FuturesAverages", today(),".PNG", sep=""))
pdf(file=paste("FuturesAverages", today(),".PDF", sep=""))
matplot(csDate2mm(benchmarkPrices$Expiration[1:14]),benchmarkPrices[1:14,c(2:5,12,17,22,23)], type='l', lwd=seq(2,5.5,0.5), xlab='Date', ylab='$/MWh', main='Futures Averages', xlim=c(2017,2020), lty=1:8, cex=1.5, col=1:8, cex.axis=1.5, cex.lab=1.5)
legend(2017.2, 140, names(benchmarkPrices[,c(2:5,12,17,22,23)]), col=1:8, lty=1:8,lwd=seq(2,5.5,0.5), cex=1.5) #, fill=1:6
graphics.off()


write.table('instrumentType = EA = Otahuhu Base Load Quarterly Futures',fileName, append = TRUE, sep = ",", dec = ".", row.names = FALSE, col.names = FALSE)
write.table('instrumentType = EE = Benmore Base Load Quarterly Futures',fileName, append = TRUE, sep = ",", dec = ".", row.names = FALSE, col.names = FALSE)
write.table(benchmarkNotes,fileName, append = TRUE, sep = ",", dec = ".", row.names = FALSE, col.names = FALSE)
write.table(instrumentType, fileName, append = TRUE, sep = ",", dec = ".", row.names = FALSE, col.names = TRUE)
write.table(benchmarkPrices, fileName, append = TRUE, sep = ",", dec = ".", row.names = FALSE, col.names = TRUE)


## Specify the Generator-retailer internal transfer prices

FYend<-c('30 June', '30 June', '30 June', '30 June', '31 March')

# Commented out the uncertainty -- think the first numbers should stand -- the latter uses revised load
# FY18a<-c(84.12, 91.72, 88.00, '76.83 (74.74 in FY19 analysis)', 82.44)
#FY19a<-c(81.08, NA, 88.00, '75.82 (76.15 in FY20)', 84.01)


# NOTE: THESE ARE REVISED NUMBERS - one year for GENESIS and CORRECTED TRUSTPOWER
# NOTE: SECOND REVISION, 24/10/2020 updated Genesis' numbers again
# GenesisOldpre23Oct<-c(91.72,  87.6,  83.7) 
# GenesisRevised<-c(80.16, 83.53, 84.40)
 
FY18<-c(84.12, 80.16, 88.00, 76.83, 83.79)
FY19<-c(81.08, 83.53, 88.00, 75.82, 85.37)
FY20<-c(87.51, 84.40, 99.00, 81.17, 88.91)
Comment<-rep('',5)
ITPs<-data.frame(cbind(FYend, FY18, FY19, FY20, Comment), row.names=c('Contact', 'Genesis', 'Mercury', 'Meridian', 'Trustpower'))
names(ITPs)<-c('FY end', 'FY18', 'FY19', 'FY20', 'Comment')
ITPs


# Format the benchmark prices into the desired form
benchmarkTable <- benchmarkPrices %>% select('Expiration', 'threeYrAvg41628', 'threeYrAvg11325', 'threeYrAvgQ', 'simpleAverage', 'mthAverage4plus', 'mthAverage456', 'mthAverage4', 'fwdAverage12Q', 'minPrice', 'maxPrice')

# Round prices to two decimal places
benchmarkTable<-round(benchmarkTable*100)/100

# Note that here the expiration dates correspond to the beginning quarter of the financial year -- not the end quarter
# The 'June year' benchmarks
benchmarkJun<-benchmarkTable[is.element(benchmarkTable$Expiration, c(2017.09, 2018.09, 2019.09)),]
benchmarkJun<-t(benchmarkJun)
rownames(benchmarkJun)<-c('Expiration', 		
		'F(t,t+3,t+6,t+9|t-4,t-16,t-28)',
		'F(t,t+3,t+6,t+9|t-1,t-13,t-25)',
		'F(t,t+3,t+6,t+9|t-4,-5,-6,-16,-17,-18,-28,-29,-30)',
		'F(t,t+3,t+6,t+9|...)',
		'F(t,t+3,t+6,t+9|t-4,-5,-6,...)',
		'F(t,t+3,t+6,t+9|t-4,-5,-6)',
		'F(t,t+3,t+6,t+9|t-4)',
		'F(t,...t+36|t-4)',
		'min(F(t,t+3,t+6,t+9|.))',
		'max(F(t,t+3,t+6,t+9|.))')
 
colnames(benchmarkJun)<-names(ITPs[2:4])
numBnchs<-dim(benchmarkJun)[1]-1
benchmarkJunTbl<-cbind(rep('30 June', nrow(benchmarkJun)), benchmarkJun, rep('',nrow(benchmarkJun)))
benchmarkJunTbl<-data.frame(benchmarkJunTbl)
colnames(benchmarkJunTbl)<-names(ITPs)
rbind(ITPs, benchmarkJunTbl)

# The 'March year' benchmark -- Note: Trustpower has March financial years, while the other generator-retailers have June years
benchmarkMar<-benchmarkTable[is.element(benchmarkTable$Expiration, c(2017.06, 2018.06, 2019.06)),]
benchmarkMar<-t(benchmarkMar)
colnames(benchmarkMar)<-names(ITPs[2:4])
rownames(benchmarkMar)<-rownames(benchmarkJun)
benchmarkMarTbl<-cbind(rep('31 March', nrow(benchmarkMar)), benchmarkMar, rep('',nrow(benchmarkMar)))
benchmarkMarTbl<-data.frame(benchmarkMarTbl)
names(benchmarkMarTbl)<-names(ITPs)
rbind(ITPs, benchmarkMarTbl)

write.table(rbind(ITPs, benchmarkJunTbl[2:nrow(benchmarkMarTbl),]), fileName, append = TRUE, sep = ",", dec = ".", row.names = FALSE, col.names = TRUE)
write.table(rbind(ITPs, benchmarkMarTbl[2:nrow(benchmarkMarTbl),]), fileName, append = TRUE, sep = ",", dec = ".", row.names = FALSE, col.names = TRUE)

# Load monthly spot data for FTR nodes
spotPrices<- read.csv("h:/my documents/D3D4/rCode/Spot Prices Monthly at FTR Nodes.csv", header=TRUE, nrow=60, fileEncoding="UTF-8-BOM")

# An approximation to Zonal prices based on the FTR nodes; not using Kikiwa b/c of shorter sample period
# (Could use zonal prices from EMI as an alternative, eg emi.ea.govt.nz/r/gochx.)
spotPrices$CNI<-(spotPrices$Whakamaru+spotPrices$Redclyffe)/2
spotPrices$LSI<-(spotPrices$Benmore+spotPrices$Invercargill)/2
spotPrices$USI<-spotPrices$Islington
spotPrices$LNI<-spotPrices$Haywards
spotPrices$UNI<-spotPrices$Otahuhu
spotPrices$startDateYM<-as.numeric(format(as.Date(spotPrices$StartDate, '%d/%m/%Y'),'%Y.%m'))

spotPriceDiffs<-spotPrices[,c(3:10)]-matrix(rep(spotPrices$Otahuhu,8), ncol=8)
spotPriceDiffs<-spotPriceDiffs %>% select(Otahuhu, Benmore, Haywards, Islington, Invercargill, Kikiwa, Whakamaru, Redclyffe)
spotPriceDiffs<-as.matrix(spotPriceDiffs)

summary(spotPriceDiffs[spotPrices$startDateYM>=2015.01,])
summarySpotPriceDiffs<-rbind(colMins(spotPriceDiffs[spotPrices$startDateYM>=2015.01,], na.rm=TRUE),
colMaxs(spotPriceDiffs[spotPrices$startDateYM>=2015.01,], na.rm=TRUE),
colMeans(spotPriceDiffs[spotPrices$startDateYM>=2015.01,], na.rm=TRUE),
colMedians(spotPriceDiffs[spotPrices$startDateYM>=2015.01,], na.rm=TRUE))
rownames(summarySpotPriceDiffs)<-c('Min','Max', 'Mean', 'Median')

zoneNames<-c('UNI', 'CNI', 'LNI', 'USI', 'LSI')
spotPriceZone<-cbind(spotPrices$UNI,spotPrices$CNI,spotPrices$LNI,spotPrices$USI,spotPrices$LSI)
rownames(spotPriceZone)<-spotPrices$startDateYM

# Subtract OTAHUHU (=UNI) prices from all others to derive an average locational (basis) spread
spotPriceDiffsZone<-spotPriceZone-matrix(rep(spotPrices$UNI,times=5),nrow=60,ncol=5)
colnames(spotPriceDiffsZone)<-zoneNames

# The following uses the same all-of-5-year-sample to compute the average spot difference, which we will use for all the FY's below -- an approximation
avgSpotPriceDiffsZone<-t(matrix(rep(colMeans(spotPriceDiffsZone),times=3),nrow=5,ncol=3))
colnames(avgSpotPriceDiffsZone)<-zoneNames
rownames(avgSpotPriceDiffsZone)<-c('FY18', 'FY19','FY20')

medianSpotPriceDiffsZone<-t(matrix(rep(colMedians(spotPriceDiffsZone),times=3),nrow=5,ncol=3))
colnames(medianSpotPriceDiffsZone)<-zoneNames
rownames(medianSpotPriceDiffsZone)<-c('FY18', 'FY19','FY20')

spotPriceZonesDF<-data.frame(rep(spotPrices$startDateYM,5), c(spotPrices$UNI,spotPrices$CNI,spotPrices$LNI,spotPrices$USI,spotPrices$LSI), 
		c(rep('UNI', nrow(spotPrices)), rep('CNI', nrow(spotPrices)), rep('LNI', nrow(spotPrices)), rep('USI', nrow(spotPrices)), rep('LSI', nrow(spotPrices))))
names(spotPriceZonesDF)<-c('startDateYM', 'spotPrice', 'ZoneID')


spotPriceZoneDiffs<-cbind(spotPrices$UNI-spotPrices$UNI,spotPrices$CNI-spotPrices$UNI,spotPrices$LNI-spotPrices$UNI,spotPrices$USI-spotPrices$UNI,spotPrices$LSI-spotPrices$UNI)
colnames(spotPriceZoneDiffs)<-zoneNames


## FTR price reporting

# See csFTRanalysis-v1.R for computation of ftr2015plus -- that illustrates the synthetic obligation FTR prices for all Source-Sink combinations
#    Source Sink SyntheticOB       Price startDateYM
#otaTemp<-data.frame('OTA',  'OTA',           as.numeric(0),           as.numeric(0),          as.numeric(NA))
#otaTemp[3:4]<-as.numeric(as.character(otaTemp[3:4]))
#names(otaTemp)<-names(ftrPrices2015plus)
#ftrPrices2015plus<-rbind(otaTemp,data.frame(ftrPrices2015plus[36:42,]))
#
# This is the required output from csFTRanalysis-v1.R
# Now includes the Obligation-FTRs in the syntheticOBL column -- startDateYM not used for anything below
#> print.data.frame(ftrPrices2015plus[36:42,])
#   Source Sink SyntheticOBL      Price startDateYM
# 1    OTA  BEN    -4.916028  1.0662993    2016.499
# 2    OTA  HAY    -3.997249  0.3257677    2017.713
# 3    OTA  INV    -8.353478  3.5197297    2018.021
# 4    OTA  ISL    -5.382000  3.8442529    2017.643
# 5    OTA  KIK    -9.376429  6.1796429    2020.435
# 6    OTA  RDF    -5.470672 -3.3555629    2020.251
# 7    OTA  WKM    -5.707016 -0.1477882    2019.739

# The following up to the next comment manually reproduces the above output so that csFTRanalysis-v1.R does not need to be run
ftrPrices2015plus<-data.frame(matrix(NA, nrow = 7,ncol = 5))
ftrPrices2015plus[1:8,1:5]<-c(
	'OTA', 'OTA',  'OTA', 'OTA', 'OTA', 'OTA', 'OTA', 'OTA', 
	'OTA', 'BEN', 'HAY', 'INV', 'ISL', 'KIK', 'RDF', 'WKM', 
	as.numeric(0), -4.916028,  -3.997249,  -8.353478,  -5.382000,  -9.376429, -5.470672, -5.707016,
	as.numeric(0), 1.0662993, 0.3257677, 3.5197297, 3.8442529, 6.1796429, -3.3555629, -0.1477882,    
	as.numeric(0), 2016.499, 2017.713, 2018.021, 2017.643, 2020.435, 2020.251, 2019.739)
names(ftrPrices2015plus)<-c('Source', 'Sink', 'SyntheticOBL', 'Price', 'startDateYM')
ftrPrices2015plus$SyntheticOBL<-as.numeric(ftrPrices2015plus$SyntheticOBL)
ftrPrices2015plus$Price<-as.numeric(ftrPrices2015plus$Price)
ftrPrices2015plus$startDateYM<-as.numeric(ftrPrices2015plus$startDateYM)


# Crudely approximating zonal basis spreads using spot prices from FTR nodes
avgFTRzonePrices<-cbind(ftrPrices2015plus$SyntheticOBL[ftrPrices2015plus$Sink=='OTA'],
	(ftrPrices2015plus$SyntheticOBL[ftrPrices2015plus$Sink=='WKM']+ftrPrices2015plus$SyntheticOBL[ftrPrices2015plus$Sink=='RDF'])/2,
	ftrPrices2015plus$SyntheticOBL[ftrPrices2015plus$Sink=='HAY'],
	ftrPrices2015plus$SyntheticOBL[ftrPrices2015plus$Sink=='ISL'],
	(ftrPrices2015plus$SyntheticOBL[ftrPrices2015plus$Sink=='BEN']+ftrPrices2015plus$SyntheticOBL[ftrPrices2015plus$Sink=='INV'])/2)
avgFTRzonePrices<-round(100*avgFTRzonePrices)/100
colnames(avgFTRzonePrices)<-zoneNames

# '2015.M1 - 2020M9'
# NOTE -- there are no FTRs for, eg, OTA-OTA so I manually added that above
print('Column as the Zone Sink')
print('Rows as the other 7 FTR sources, so they do not line up')
print(avgFTRzonePrices)
print.data.frame(ftrPrices2015plus)

# The following replicates the monthly relative price differences
spotPriceRelAvgDF<-spotPriceZonesDF %>% select(startDateYM, spotPrice, ZoneID) %>% 
    mutate(mth=round(100*startDateYM%%1)) %>% group_by(ZoneID, mth) %>%summarise(avgSpotPrice=mean(spotPrice))
print.data.frame(spotPriceRelAvgDF)
zoneMthPriceRelAvgDF<-spotPriceRelAvgDF %>% select(ZoneID, avgSpotPrice, mth) %>% 
    group_by(ZoneID) %>% mutate(avgavgPrice=mean(avgSpotPrice)) %>% summarise (mth, relMthSpotPrice=avgSpotPrice/avgavgPrice)
print.data.frame(zoneMthPriceRelAvgDF)
zoneMthPriceRelAvg<-matrix(zoneMthPriceRelAvgDF$relMthSpotPrice,12,5)
colnames(zoneMthPriceRelAvg)<-zoneNames
rownames(zoneMthPriceRelAvg)<-1:12

# Monthly price relative to an annual average (i.e. expressed as a proportion: if month prices were constant then we would have a column vector of 1's)
# mthPriceRelAvg<-c(
# 0.997284619,	1.00044753,		1.033316846,	1.027795656,	1.056459169,	1.033087062,	0.989810043,	1.013832972,
# 0.943565927,	0.945473723,	0.80403764,		0.852815768,	0.837636503,	0.85462201,		0.940487757,	0.921406406,
# 0.939115461,	0.943044803,	0.848108481,	0.875720032,	0.879913168,	0.873462366,	0.93420345,		0.929303397,
# 0.727103302,	0.727584023,	0.618770941,	0.705784393,	0.703102335,	0.701127191,	0.727921612,	0.70986689,
# 0.932361487,	0.935312371,	0.842537646,	0.91390185,		0.908370467,	0.911593806,	0.932553026,	0.906565509,
# 1.177450226,	1.176845041,	1.086312689,	1.207433628,	1.214033638,	1.21279161,		1.177027368,	1.180259791,
# 1.166760161,	1.162895465,	1.002400174,	1.210353982,	1.230717993,	1.216081912,	1.171843344,	1.186704462,
# 1.015086484,	1.018207613,	0.980933504,	1.052606597,	1.050055073,	1.053775396,	1.021654762,	1.01952879,
# 0.812936916,	0.811615733,	0.989931422,	0.87084473,		0.896116012,	0.87026221,		0.813785977,	0.834380655,
# 1.263462753,	1.255394969,	1.963412841,	1.343990346,	1.317414045,	1.342059894,	1.265113458,	1.291974985,
# 1.138178775,	1.135352853,	1.136012697,	1.043628319,	1.01772161,		1.037256279,	1.141627889,	1.121009665,
# 0.886693889,	0.887825875,	0.694225121,	0.895124698,	0.888459987,	0.893880265,	0.883971315,	0.885166478)
# mthPriceRelAvg<-t(matrix(mthPriceRelAvg, 8,12))
# colnames(mthPriceRelAvg)<-c('Whakamaru',	'Redclyffe',	'Kikiwa',	'Benmore',	'Invercargill',	'Islington',	'Otahuhu',	'Haywards')
# mthPriceRelAvg
# matplot((1:12), mthPriceRelAvg[,c(1,4,6,7,8,2,3,5)],type='l',lwd=3)



###################################################################
# Do the load averaging 


numZones<-5
numMonths<-12
numYears<-3

# Specify which benchmark futures to use (eg June or March)
doJune<-TRUE
ifelse(doJune,tempFutures<-benchmarkJun,tempFutures<-benchmarkMar)


# Add an adjustment for location (held constant across fiscal years in current implementation)
locAdjFuture<-array(NA, dim=c(numBnchs,numZones,numYears))
for (ttt in 1:3){
	# iterate through the number of zones
	for (z in 1:5){
	# NB: avgSpotPrice columns run north-south
	# Note: the first row in benchmarkJun is an expiration data
	locAdjFuture[,z,ttt]<-tempFutures[2:(1+numBnchs),ttt]+avgSpotPriceDiffsZone[ttt,z]
	}
}
# Should be using dimnames
colnames(locAdjFuture)<-zoneNames
rownames(locAdjFuture)<-rownames(benchmarkJun)[2:(numBnchs+1)]
locAdjFuture


# Interpolate monthly price seasonality
# If all months had the same prices then we would have 1s in each column
# NOTE: The first dimension corresponds to Zones; the second to months; the third to the type of futures used ('Benchmark'); and the last corresponds to FY18,FY19,FY20
locTimeBenchFY<-array(NA, dim=c(numZones,numMonths,numBnchs,numYears), dimnames=list(zoneNames,1:12,rownames(benchmarkJun)[2:(numBnchs+1)],colnames(benchmarkJun)))
for (b in 1:numBnchs){
	for (z in 1:numZones){
		for (ttt in 1:numYears){
			locTimeBenchFY[z,,b,ttt]<-locAdjFuture[b,z,ttt]*zoneMthPriceRelAvg[,z]
 		}
	}
}



## Compute the resultant ITPs -- taking account of different possible load profiles

# NOTE: Need to have run csLoadAnalysisITP-V2.R so that the load matrices are in memory


fileNameITPs<-paste('InternalTransferPrices-', today(), '-v1.csv', sep='')

# Write the generator-retail internal transfer prices
write.table('Generator-retail ITPs', file=fileNameITPs, append=FALSE, sep=',')
write.table(ITPs, file=fileNameITPs, append=TRUE, sep=',')

# Perfectly balanced load across Zones and months (5 zones * 12 months = 60 cells =>  average weight = 1/60)
avgLoadWgts<-matrix(1/60,5,12)
# Compute the ITPs given generic avgLoadWeights
annualITPsAverage<-csLoadWeightPrices(avgLoadWgts,locTimeBenchFY)
print(annualITPsAverage,)
write.table('annualITPsAverage', file=fileNameITPs, append=TRUE, sep=',')
write.table(annualITPsAverage, file=fileNameITPs, append=TRUE, sep=',')

# ITPs from ALL retailers
annualITPsAll<-csLoadWeightPrices(offtakeAllMat,locTimeBenchFY)
print('ITPs from ALL retailers')
print(annualITPsAll, digits=4)
write.table('annualITPsAll', file=fileNameITPs, append=TRUE, sep=',')
write.table(annualITPsAll, file=fileNameITPs, append=TRUE, sep=',')

# Load across Auckland only, based on the offtakeAllMat profile for UNI load
UNIonlyWgts<-offtakeAllMat
UNIonlyWgts[2:5,]<-0
UNIonlyWgts<-UNIonlyWgts/sum(UNIonlyWgts)

# Compute the ITPs given generic avgLoadWeights
annualITPsUNIonly<-csLoadWeightPrices(UNIonlyWgts,locTimeBenchFY)
print(annualITPsUNIonly)
write.table('annualITPsUNIonly', file=fileNameITPs, append=TRUE, sep=',')
write.table(annualITPsUNIonly, file=fileNameITPs, append=TRUE, sep=',')

# Compute the differences between a 'National' and an 'Auckland' strategy
write.table('annualITPsUNIonly-annualITPsAll', file=fileNameITPs, append=TRUE, sep=',')
write.table(annualITPsUNIonly-annualITPsAll, file=fileNameITPs, append=TRUE, sep=',')

# Compute the ITPs given load weights from independents including Nova
annualITPsIndependents<-csLoadWeightPrices(offtakeIndependentsMat,locTimeBenchFY)
print('ITPs from Independents-incl-Nova retailers load weights')
print(annualITPsIndependents, digits=4)
write.table('annualITPsIndependents', file=fileNameITPs, append=TRUE, sep=',')
write.table(annualITPsIndependents, file=fileNameITPs, append=TRUE, sep=',')

# Compute the ITPs given load weights from independent weights exclude Nova
annualITPsIndependentsExNova<-csLoadWeightPrices(offtakeIndependentsExNovaMat,locTimeBenchFY)
print('ITPs from Independents-ex-Nova retailer load weights')
print(annualITPsIndependentsExNova, digits=4)
write.table('annualITPsIndependentsExNova', file=fileNameITPs, append=TRUE, sep=',')
write.table(annualITPsIndependentsExNova, file=fileNameITPs, append=TRUE, sep=',')

# Compute the ITPs given load weights from integrated retailers
annualITPsIntegrated<-csLoadWeightPrices(offtakeIntegratedMat,locTimeBenchFY)
print('ITPs from vertically integrated retailer load weights')
print(annualITPsIntegrated, digits=4)
write.table('annualITPsIntegrated', file=fileNameITPs, append=TRUE, sep=',')
write.table(annualITPsIntegrated, file=fileNameITPs, append=TRUE, sep=',')

# Compute the ITPs given load weights from Contact
annualITPsContact<-csLoadWeightPrices(offtakeContactMat,locTimeBenchFY)
print('ITPs from Contact load weights')
print(annualITPsContact, digits=4)
write.table('annualITPsContact', file=fileNameITPs, append=TRUE, sep=',')
write.table(annualITPsContact, file=fileNameITPs, append=TRUE, sep=',')

# Compute the ITPs given load weights from Genesis
annualITPsGenesis<-csLoadWeightPrices(offtakeGenesisMat,locTimeBenchFY)
print('ITPs from Genesis load weights')
print(annualITPsGenesis, digits=4)
write.table('annualITPsGenesis', file=fileNameITPs, append=TRUE, sep=',')
write.table(annualITPsGenesis, file=fileNameITPs, append=TRUE, sep=',')

# Compute the ITPs given load weights from Mercury
annualITPsMercury<-csLoadWeightPrices(offtakeMercuryMat,locTimeBenchFY)
print('ITPs from Mercury load weights')
print(annualITPsMercury, digits=4)
write.table('annualITPsMercury', file=fileNameITPs, append=TRUE, sep=',')
write.table(annualITPsMercury, file=fileNameITPs, append=TRUE, sep=',')

# Compute the ITPs given load weights from Meridian
annualITPsMeridian<-csLoadWeightPrices(offtakeMeridianMat,locTimeBenchFY)
print('ITPs from Meridian load weights')
print(annualITPsMeridian, digits=4)
write.table('annualITPsMeridian', file=fileNameITPs, append=TRUE, sep=',')
write.table(annualITPsMeridian, file=fileNameITPs, append=TRUE, sep=',')

write.table('annualITPsMeridian-annualITPsAll', file=fileNameITPs, append=TRUE, sep=',')
write.table(annualITPsMeridian-annualITPsAll, file=fileNameITPs, append=TRUE, sep=',')

# Compute the ITPs given load weights from Trustpower
annualITPsTrustpower<-csLoadWeightPrices(offtakeTrustpowerMat,locTimeBenchFY)
print('ITPs from Trustpower load weights')
print(annualITPsTrustpower, digits=4)
write.table('annualITPsTrustpower', file=fileNameITPs, append=TRUE, sep=',')
write.table(annualITPsTrustpower, file=fileNameITPs, append=TRUE, sep=',')



##########################################################################################
## Do a comparison with no time adjustment



# Interpolate across the seasonal (monthly) dimension
# NOTE: The first dimension corresponds to Zones; the second to months; the third to the type of futures used ('Benchmark'); and the last corresponds to FY18,FY19,FY20
locTimeBenchFY_FLAT<-array(NA, dim=c(numZones,numMonths,numBnchs,numYears), dimnames=list(zoneNames,1:12,rownames(benchmarkJun)[2:(numBnchs+1)],colnames(benchmarkJun)))
for (b in 1:numBnchs){
	for (z in 1:numZones){
		for (ttt in 1:numYears){
			locTimeBenchFY_FLAT[z,,b,ttt]<-locAdjFuture[b,z,ttt]*rep(1,12)
 		}
	}
}

# This assumes a flat seasonal profile across months
annualITPsAll_FLAT<-csLoadWeightPrices(offtakeAllMat,locTimeBenchFY_FLAT)
print('ITPs from ALL retailers with FLAT SEASONALITY')
print(annualITPsAll_FLAT, digits=4)
#write.table('annualITPsAll_FLAT', file=fileNameITPs, append=TRUE, sep=',')
#write.table(annualITPsAll_FLAT, file=fileNameITPs, append=TRUE, sep=',')



# Perfectly balanced load across Zones and months (5 zones * 12 months = 60 cells) WITH FLAT price seasonality
avgLoadWgts<-matrix(1/60,5,12)
# Compute the ITPs given generic avgLoadWeights
annualITPsAverage_FLAT<-csLoadWeightPrices(avgLoadWgts,locTimeBenchFY_FLAT)
print(annualITPsAverage_FLAT, digits=4)
write.table('annualITPsAverage_FLAT', file=fileNameITPs, append=TRUE, sep=',')
write.table(annualITPsAverage_FLAT, file=fileNameITPs, append=TRUE, sep=',')
write.table('annualITPsAll-annualITPsAverage_FLAT', file=fileNameITPs, append=TRUE, sep=',')
write.table(annualITPsAll-annualITPsAverage_FLAT, file=fileNameITPs, append=TRUE, sep=',')


write.table('annualITPsAll-annualITPsAverage', file=fileNameITPs, append=TRUE, sep=',')
write.table(annualITPsAll-annualITPsAverage, file=fileNameITPs, append=TRUE, sep=',')

print()


##############################################################################################
# Draw a picture of the ITPs

tmpDate<-c(2017.5, 2017.5, 2017.5, 2017.5, 2017.25)
fyIndex<-matrix(c(tmpDate, tmpDate+1,tmpDate+2),15,1)  
fyIndexP1<-fyIndex+1
vecITPs<-as.matrix(c(FY18, FY19, FY20),nrow=15)


# Exclude the Expiration date; include everything except the straight t-4 row; include the Mercury-equivalent benchmark row; exclude the min and max rows
inclRows<-c(2:7,9)
upper<-colMaxs(benchmarkJun[inclRows,1:3])
lower<-colMins(benchmarkJun[inclRows,1:3])
upperMar<-colMaxs(benchmarkMar[inclRows,1:3])
lowerMar<-colMins(benchmarkMar[inclRows,1:3])

# Figure3 - with extra bands
#png(paste('Fig3ITPsBenchmarks50-200-MarJun-', today(), '.png', sep=''), bg='transparent')
pdf(paste('Fig3ITPsBenchmarks50-200-MarJun-', today(), '.pdf', sep=''), bg='transparent')
#plot.new()
matplot(t(cbind(fyIndex, fyIndexP1)), t(cbind(vecITPs, vecITPs)),lty=1:5,type='l',lwd=3, col=1:5, xlab='Calendar Years', ylab='$/MWh', cex=1.5, cex.lab=1.5, cex.axis=1.5, ylim=c(50,200),xlim=c(2017,2021))

# March polygons
marchColour<- rgb(10, 255, 204, 204, maxColorValue=255)	# First number is the 'alpha' which dictates transparency
polygon(c(2017.25, 2018.25,2018.25, 2017.25), c(upperMar[1],upperMar[1], lowerMar[1], lowerMar[1]), col=marchColour, border=NA)
polygon(c(2018.25, 2019.25,2019.25, 2018.25), c(upperMar[2],upperMar[2], lowerMar[2], lowerMar[2]), col=marchColour, border=NA)
polygon(c(2019.25, 2020.25,2020.25, 2019.25), c(upperMar[3],upperMar[3], lowerMar[3], lowerMar[3]), col=marchColour, border=NA)

# Draw the polygons first so that they are under the ITP lines -- though now added transparency alpha
# col2rgb("gray", alpha=TRUE)	# Specify a named colour in rgb terms
graytransparent <- rgb(10, 100, 100, 100, maxColorValue=255)	# First number is the 'alpha' which dictates transparency
polygon(c(2017.5, 2018.5,2018.5, 2017.5), c(upper[1],upper[1], lower[1], lower[1]), col=graytransparent)
polygon(c(2018.5, 2019.5,2019.5, 2018.5), c(upper[2],upper[2], lower[2], lower[2]), col=graytransparent)
polygon(c(2019.5, 2020.5,2020.5, 2019.5), c(upper[3],upper[3], lower[3], lower[3]), col=graytransparent)
par(new=TRUE)
matplot(t(cbind(fyIndex, fyIndexP1)), t(cbind(vecITPs, vecITPs)),lty=1:5,type='l',lwd=3, col=1:5, xlab='Calendar Years', ylab='$/MWh', cex=1.5, cex.lab=1.5, cex.axis=1.5, ylim=c(50,200),xlim=c(2017,2021)) # was 70 to 105
legend(c('Contact','Genesis','Mercury', 'Meridian','Trustpower'),lty=1:5, y=180, x=2017.1, col=1:5, lwd=3, cex=1.4) # was 106 location
dev.off()


# Figure3 - standard
#png(paste('Fig3ITPsBenchmarksStandard-200-Jun-', today(), '.png', sep=''), bg='transparent')
pdf(paste('Fig3ITPsBenchmarksStandard-200-JunA-', today(), '.pdf', sep=''), bg='transparent')
#dev.new()
matplot(t(cbind(fyIndex, fyIndexP1)), t(cbind(vecITPs, vecITPs)),lty=1:5,type='l',lwd=3, col=1:5, xlab='Calendar Years', ylab='$/MWh', cex=1.5, cex.lab=1.5, cex.axis=1.5, ylim=c(50,200),xlim=c(2017,2021))

# Draw the polygons first so that they are under the ITP lines -- though now added transparency alpha
# col2rgb("gray", alpha=TRUE)	# Specify a named colour in rgb terms
graytransparent <- rgb(10, 100, 100, 100, maxColorValue=255)	# First number is the 'alpha' which dictates transparency
polygon(c(2017.5, 2018.5,2018.5, 2017.5), c(upper[1],upper[1], lower[1], lower[1]), col=graytransparent)
polygon(c(2018.5, 2019.5,2019.5, 2018.5), c(upper[2],upper[2], lower[2], lower[2]), col=graytransparent)
polygon(c(2019.5, 2020.5,2020.5, 2019.5), c(upper[3],upper[3], lower[3], lower[3]), col=graytransparent)
par(new=TRUE)
matplot(t(cbind(fyIndex, fyIndexP1)), t(cbind(vecITPs, vecITPs)),lty=1:5,type='l',lwd=3, col=1:5, xlab='Calendar Years', ylab='$/MWh', cex=1.5, cex.lab=1.5, cex.axis=1.5, ylim=c(50,200),xlim=c(2017,2021)) # was 70 to 105
legend(c('Contact','Genesis','Mercury', 'Meridian','Trustpower'),lty=1:5, y=180, x=2017.1, col=1:5, lwd=3, cex=1.4) # was 106 location
dev.off()



#
spotPrices$Otahuhu
spotDate<-as.numeric(format(as.Date(spotPrices$StartDate, '%d/%m/%Y'),'%Y.%m'))


# XXX
nextYearFuture<-df %>% select(MeanPrice, ExpirationYM, settlementMonthYM, Instrument) %>% group_by(settlementMonthYM) %>% filter(Instrument=='EA' & ExpirationYM>=settlementMonthYM & ExpirationYM<(settlementMonthYM+1)) %>% summarise (min(ExpirationYM), annualFuture=mean(MeanPrice))
# print.data.frame(nextYearFuture)


# Checking data -- key error was not-subsetting to given Instrument type, eg Instrument=EA
# tmp<-df %>% select(MeanPrice, ExpirationYM, settlementMonthYM, Instrument) %>% group_by(settlementMonthYM) %>% filter(Instrument=='EA' & (ExpirationYM>=settlementMonthYM) & (ExpirationYM<(settlementMonthYM+1))) %>% arrange(settlementMonthYM)
# print.data.frame(tmp)

# cbind(df$ExpirationYM, df$settlementMonthYM, df$settlementMonthYM+1, df$MonthsRemainingToExpiry)
# cbind(nextYearFuture$settlementMonthYM, nextYearFuture$annualFuture)


# Figure 1: Spot price; average of forward-curve for the next four quarter; threeYrAvg41628 hedge price
png(paste('Fig1SpotFwdFuturesHedge', today(), '.png',sep=''), bg='transparent') 	
matplot(csDate2mm(spotDate),spotPrices$Otahuhu, type='l', lwd=4, col='blue', xlim=c(2017,2021), ylim=c(50,200), xlab='Years', ylab='$/MWh', lty=1, cex=1.5, cex.lab=1.5, cex.axis=1.5)
par(new=TRUE)
polygon(csDate2mm(c(2021.02,2021.02,2021.12,2021.12)),c(0,200,200,0), col='white', border=NA) #col='azure' is pretty good
par(new=TRUE)
matplot(csDate2mm(benchmarkPrices$Expiration),benchmarkPrices$threeYrAvg41628, type='l', lwd=4, col='red', xlim=c(2017,2021), ylim=c(50,200), xlab='Years', ylab='$/MWh', lty=2, cex=1.5, cex.lab=1.5, cex.axis=1.5)
par(new=TRUE)
matplot(csDate2mm(nextYearFuture$settlementMonthYM),nextYearFuture$annualFuture, type='l',lwd=4,col='purple', xlim=c(2017,2021), ylim=c(50,200), xlab='Years', ylab='$/MWh', lty=3, cex=1.5, cex.lab=1.5, cex.axis=1.5)
legend(2019.2, 195, c('Spot Price (Otahuhu)','Futures price for coming year','Representative hedge price'), lty=c(1, 2, 3), col=c('blue', 'purple', 'red'), lwd=c(4,4,4), cex=.8)
dev.off()


# Figure 2 PNG: Spot price against the ITPs
png(paste('Fig2SpotPriceandITPs-', today(), '.png',sep=''), bg='transparent') 	
matplot(csDate2mm(spotDate),spotPrices$Otahuhu, type='l', lwd=2, col='blue', xlim=c(2017,2021), ylim=c(50,200), xlab='Calendar Years', ylab='$/MWh', lty=1, cex=1.5, cex.lab=1.5, cex.axis=1.5)
par(new=TRUE)
matplot(t(cbind(fyIndex, fyIndexP1)), t(cbind(vecITPs, vecITPs)),lty=1:5,type='l',lwd=4, col=c(1,1:5), xlab='Calendar Years', ylab='$/MWh', cex=1.5, cex.lab=1.5, cex.axis=1.5, ylim=c(50,200),xlim=c(2017,2021))
# Note blue=4 for col, to match first matplot of the spot price
legend(c('Spot Price (Otahuhu)', 'Contact','Genesis','Mercury', 'Meridian','Trustpower'),lty=c(1,1:5), y=180, x=2017.0, col=c(4,1:5), lwd=3, cex=.9)
dev.off()



# Figure 2 PDF: Spot price against the ITPs
pdf(paste('Fig2SpotPriceandITPs-', today(), '.pdf',sep=''), bg='transparent') 	
#dev.new()
matplot(csDate2mm(spotDate),spotPrices$Otahuhu, type='l', lwd=2, col='blue', xlim=c(2017,2021), ylim=c(50,200), xlab='Calendar Years', ylab='$/MWh', lty=1, cex=1.5, cex.lab=1.5, cex.axis=1.5)
par(new=TRUE)
matplot(t(cbind(fyIndex, fyIndexP1)), t(cbind(vecITPs, vecITPs)),lty=1:5,type='l',lwd=4, col=c(1:5), xlab='Calendar Years', ylab='$/MWh', cex=1.5, cex.lab=1.5, cex.axis=1.5, ylim=c(50,200),xlim=c(2017,2021))
legend(c('Spot Price (Otahuhu)', 'Contact','Genesis','Mercury', 'Meridian','Trustpower'),lty=c(1,1:5), y=180, x=2017.0, col=c(4,1:5), lwd=3, cex=.9)
dev.off()



# Look at spot price data from Otahuhu
cbind(spotDate, spotPrices$Otahuhu)

# ## An example of how to shade the region
# curve(dnorm(x,0,1),xlim=c(-3,3),main='Normal Density')
# cord.x <- c(-3,seq(-3,-2,0.01),-2) 
# cord.y <- c(0,dnorm(seq(-3,-2,0.01)),0) 
# curve(dnorm(x,0,1),xlim=c(-3,3),main='Standard Normal') 
# polygon(cord.x,cord.y,col='skyblue')
