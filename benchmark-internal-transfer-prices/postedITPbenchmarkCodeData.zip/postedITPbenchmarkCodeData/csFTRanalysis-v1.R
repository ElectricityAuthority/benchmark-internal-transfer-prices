# csFTRanalysis
#
# Purpose: Analyse FTR data
#
# Christie Smith  15 September 2020
#
# Inputs: N/A
#
# Outputs: Displays or possible provides file with FTR prices for price differentials between the 8 [as of 2020] FTR nodes at given dates.
#
# Requires: FTR_Register.csv -- data from the FTR register (join and log in at www.ftr.co.nz).
#
#
# NOTE: Consider two nodes A & B. Let OB=obligations and OP=Options. 
# Then: 	P(OBAB) = P(OPAB)-P(OPBA)
#		P(OBBA) = P(OPBA) - P(OPAB) and 
#		P(OBAB) = - P(OBBA)
# See  p. 15 AN INTRODUCTION TO THE NEW ZEALAND FTR MARKET, v1.2 11 November 2012, available at www.ftr.co.nz.
#

#library(dplyr)
library(tidyverse)

setwd('H:/My Documents/D3D4/rCode')

ftr<-read.csv("FTR_register.csv", header=TRUE, fileEncoding="UTF-8-BOM")

# Remove the "assigned" rows, where an FTR contract is assigned to a new owner; these rows have blank (empty) AuctionName elements
ftr<-ftr[!(ftr$AuctionName==""),]

# ftr$AuctionName is a 'factor', see class(ftr$AuctionName)
auctionDate<-as.character(ftr$AuctionName)
auctionDate<-strsplit(auctionDate, "_")	

auctionPriVar<-unlist(auctionDate)[3*(1:nrow(ftr))-2]
auctionMonth<-unlist(auctionDate)[3*(1:nrow(ftr))-1]
auctionYear<-unlist(auctionDate)[3*(1:nrow(ftr))]
auctionYear<-as.numeric(auctionYear)

auctionMonth[auctionMonth=='JAN']<-0.01
auctionMonth[auctionMonth=='FEB']<-0.02
auctionMonth[auctionMonth=='MAR']<-0.03
auctionMonth[auctionMonth=='APR']<-0.04
auctionMonth[auctionMonth=='MAY']<-0.05
auctionMonth[auctionMonth=='JUN']<-0.06
auctionMonth[auctionMonth=='JUL']<-0.07
auctionMonth[auctionMonth=='AUG']<-0.08
auctionMonth[auctionMonth=='SEP']<-0.09
auctionMonth[auctionMonth=='OCT']<-0.10
auctionMonth[auctionMonth=='NOV']<-0.11
auctionMonth[auctionMonth=='DEC']<-0.12
auctionMonth<-as.numeric(auctionMonth)

# Note: Not distinguishing between Primary and Variation auctions
auctionYM<-auctionYear+auctionMonth

# This is the beginning-of-the-month date to which the contract pertains (expirationDate in the language of the futures data)
# Note: all contracts are currently for a single month, but different-duration contracts were envisaged, 
# so there is an EndDate for each contract too.
startDateYM<-as.numeric(format(as.Date(ftr$StartDate, '%d/%m/%Y'),'%Y.%m'))

# Short for month-separation
monthSep<-as.integer(floor(startDateYM)*12+100*(startDateYM-floor(startDateYM)) - floor(auctionYM)*12+100*(auctionYM-floor(auctionYM)))

# Add auctionYM (year-month) and startDate to the dataframe
ftr$auctionYM<-auctionYM
ftr$auctionPriVar<-auctionPriVar
ftr$startDateYM<-startDateYM
ftr$monthSep<-monthSep
ftr$startDateYM<-startDateYM
ftr$SinkNum<-case_when(ftr$Sink=='OTA' ~1, ftr$Sink=='BEN' ~2, ftr$Sink=='HAY' ~3,ftr$Sink=='ISL' ~4,ftr$Sink=='INV' ~5,ftr$Sink=='KIK' ~6,ftr$Sink=='WKM' ~7,ftr$Sink=='RDF' ~8)
ftr$SourceNum<-case_when(ftr$Source=='OTA' ~1, ftr$Source=='BEN' ~2, ftr$Source=='HAY' ~3,ftr$Source=='ISL' ~4,ftr$Source=='INV' ~5,ftr$Source=='KIK' ~6,ftr$Source=='WKM' ~7,ftr$Source=='RDF' ~8)


## Compute a synthetic obligations price series based on the options prices

# # I couldn't quite make this work
# source_order_compare_min = function(s_1, s_2){
#   case_when(s_1 > s_2 ~ s_2,
#             TRUE ~ s_1)
# }
# 
# # Another function
# source_order_compare_max = function(s_1, s_2){
#   case_when(s_1 <= s_2 ~ s_2,
#             TRUE ~ s_1)
# }
# 
# example<- ftr %>% select(AuctionName, Price, StartDate, EndDate, HedgeType) %>% filter(HedgeType=='OPT') %>%
#   mutate(source_sink_group_1 = source_order_compare_min(ftr$SinkNum, ftr$SourceNum),
#          source_sink_group_2 = source_order_compare_max(ftr$SourceNum, ftr$SinkNum)) %>% 
#   group_by(source_sink_group_1, source_sink_group_2, ftr$AuctionName) %>% 
#   mutate(price_diff = 2* ftr$Price - sum(ftr$Price)) %>% 
#   ungroup()

# Iterate through each row in turn, if an option look for its counterpart with switched sources-sinks
# NB the loop takes a couple of minutes to run
# REM: P(OBBA) = P(OPBA) - P(OPAB); see introductory note 
sinkNames<-unique(ftr$Sink)
ftr$SyntheticOBL=matrix(NA,nrow(ftr),1)
for (ttt  in 1:nrow(ftr)){
	auctionTemp<-ftr$AuctionName[ttt]
	temp<-NA
	if (ftr$HedgeType[ttt]=='OPT'){
		# ftr$Price[ftr$AuctionName==auctionTemp & ftr$Source==ftr$Sink[ttt] & ftr$Sink==ftr$Source[ttt] & ftr$HedgeType=='OPT' & ftr$DateAcquired==ftr$DateAcquired[ttt] & ftr$StartDate==ftr$StartDate[ttt],]
		# ftr[ttt,]
		# REM: tempB could have multiple rows, but we are choosing just the first row with the [1] at the end -- because the prices struck at a given date is all the same
		tempB<-ftr$Price[ftr$AuctionName==auctionTemp & ftr$Source==ftr$Sink[ttt] & ftr$Sink==ftr$Source[ttt] & ftr$HedgeType=='OPT' & ftr$DateAcquired==ftr$DateAcquired[ttt] & ftr$StartDate==ftr$StartDate[ttt]][1]
		ftr$SyntheticOBL[ttt]<-ftr$Price[ttt]-tempB
		if(ttt%%1000==0){print(ttt)}
		}	
}

# Use the actual OBL prices where available
ftr$SyntheticOBL[ftr$HedgeType=='OBL']<-ftr$Price[ftr$HedgeType=='OBL']

ftrPrices2015plus<-ftr %>% select(Source, Sink, SyntheticOBL,Price, startDateYM) %>% filter(startDateYM>=2015.01) %>% group_by(Source, Sink) %>% summarise_each(funs(mean(.,na.rm = TRUE) ))
view(ftrPrices2015plus)

matplot(ftr2015plus$Price,ftr2015plus$SyntheticOBL,lwd=3, ylim=c(-10,10),xlim=c(-10,10), type='p', pch=20)
points(ftr2015plus$Price,ftr2015plus$SyntheticOBL, type="p", pch=20, lwd=3, ylim=c(-10,10),xlim=c(-10,10))  
par(new=TRUE)
matplot(-10:10,-10:10,type='l',col='blue')



## Date function, to make YYYYMM dates more graphing-friendly

# Define a function to convert dates to a plot-friendly sequence
csDate2mm<-function(ttt){
# Purpose: Define a function to convert dates to a plot-friendly sequence
# INPUT: Monthly date sequence like 2009.08, 2009.09, 2009.10, 2009.11, 2009.12
# OUTPUT: t: Monthly date sequence where 2009+8/12-1/24, 2009+9/12-1/24, etc. so that each element is centered in 1/12
t<-floor(ttt)+100*(ttt-floor(ttt))*1/12 - 1/12
t}



# Can remove duplicates associated with multiple contract owners
ftrUnique<-unique(subset(ftr,select=-c(FTR_ID, CurrentOwner, PreviousOwner, FirstOwner, MW, AcquisitionCost, 
		OriginalAcquisitionCost,Status,AllocationPlan)))
ftrUnique<-ftrUnique[order(ftrUnique$startDateYM),]

rowIdxs<-(ftrUnique$Source=='HAY' & ftrUnique$Sink=='BEN' & is.element(ftrUnique$monthSep,1:12))
matplot(csDate2mm(ftrUnique$startDateYM[rowIdxs]),ftrUnique$SyntheticOBL[rowIdxs],type='l')

ftr[1:100,c(1:4, 7:ncol(ftr))]

# Chop some cols so it displays in a given Console width
ftr[47326:47426,c(1:4, 7:ncol(ftr))]


# This provides FTRs relative to OTA (no OTA-OTA row for obvious reasons)
print.data.frame(ftr2015plus[36:42,])

# Confirms the selection above
# mean(ftr$SyntheticOBL[ftr$Source==sinkNames[1] & ftr$Sink==sinkNames[2] & ftr$startDateYM>=2015.01],na.rm = TRUE)



## Pictures Price of FTRs for different Source-Sink

# Initialise heatmap matrix of median prices
# NB: ROWS correspond to SOURCE and COLS correspond to SINK 
heatmapMedianFTRPrice<-matrix(NA, 8,8)
colnames(heatmapMedianFTRPrice)<-sinkNames
rownames(heatmapMedianFTRPrice)<-sinkNames
heatmapMeanFTRPrice<-heatmapMedianFTRPrice
heatmapMedianFTRPrice2015<-heatmapMedianFTRPrice
heatmapMeanFTRPrice2015<-heatmapMedianFTRPrice

# Do a bunch of plots for different source-sinks -- comment out the png or pdf command depending on what files you want
for (ii in 1:8){
	for (jj in setdiff(1:8,ii)){
		#plot.new()
		png(paste('FTRSourceSink-',sinkNames[ii], '-',sinkNames[jj],'-',today(),'.png',sep=''))
		# pdf(paste('FTRSourceSink-',sinkNames[ii], '-',sinkNames[jj],'-',today(),'.pdf',sep=''))
		matplot(csDate2mm(ftrUnique$startDateYM[ftrUnique$Source==sinkNames[ii] & ftrUnique$Sink==sinkNames[jj]]), 
			ftrUnique$SyntheticOBL[ftrUnique$Source==sinkNames[ii] & ftrUnique$Sink==sinkNames[jj]], 
			type='p', pch=20,lwd=3, main=paste('Source and Sink: ', sinkNames[ii], sinkNames[jj]),
			xlab='Contract Month', ylab='$/MWh',col='blue')
		#Sys.sleep(0)

		# NB: ROWS correspond to SOURCE and COLS correspond to SINK
		heatmapMedianFTRPrice[ii,jj]=median(ftrUnique$SyntheticOBL[ftrUnique$Source==sinkNames[ii] & ftrUnique$Sink==sinkNames[jj]],na.rm=TRUE)
		heatmapMeanFTRPrice[ii,jj]=mean(ftrUnique$SyntheticOBL[ftrUnique$Source==sinkNames[ii] & ftrUnique$Sink==sinkNames[jj]],na.rm=TRUE)
		heatmapMedianFTRPrice2015[ii,jj]=median(ftrUnique$SyntheticOBL[ftrUnique$Source==sinkNames[ii] & ftrUnique$Sink==sinkNames[jj] & ftrUnique$startDateYM>=2015.09],na.rm=TRUE)
		heatmapMeanFTRPrice2015[ii,jj]=mean(ftrUnique$SyntheticOBL[ftrUnique$Source==sinkNames[ii] & ftrUnique$Sink==sinkNames[jj] & ftrUnique$startDateYM>=2015.09],na.rm=TRUE)
	}
}
#graphics.off()

# Print a table of the median FTR price differences for different source-sink locations
# Note: Not symmetric because sometimes FTR is traded A -> B but not also B -> A; i.e. sample periods can differ
print.table(heatmapAvgFTRPrice, sep=',')


# ## Analyse the obligations only -- this section of code is obsolete now, given the syntheticOBL series that has been created
# 
# # Pulls out the 'obligations' (cf. 'options') -- Obligations give clean payoffs akin to a futures contract
# ftrOBL<-ftr[ftr$HedgeType=='OBL',]
# 
# ftrOBL[ftrOBL$Source=='OTA'&ftrOBL$Source=='BEN',]
# 
# ftrOBL %>% group_by(AuctionYM) %>% summarise(across(starts_with("PRI"), mean(.x, na.rm = TRUE)))
# 
# 
# ## Do the business
# 
# # Select columns, fiter, etc.
# ftrOblPairs<- ftrOBL %>% select(Source, Sink, Price, auctionYM, monthSep, StartDate, startDateYM) %>% filter(monthSep %in% as.integer(c(1:50))) 
# %>% group_by(Sink, Source, StartDate) %>% mutate(avgPrice=mean(Price)) %>% summarise(Sink, Source, startDateYM, avgPrice) 
# ftrOblPairs<- ftrOblPairs %>% arrange(Sink, Source, startDateYM) 
# ftrOblPairs<- distinct(ftrOblPairs)
# view(ftrOblPairs)
# 
# # Draw a chart
# 
# # Define the (8) Node names
# nodeNames<-unique(ftr$Source);
# 
# 
# 
# ttt<-csDate2plotDateMonthly(startDateYM)
# 
# for (ii in nodeNames)
# for (jj in nodeNames)
# {{if(ii==jj){break}
# pdf(paste(ii,'to', jj,'-',today(),'.pdf',sep=''))
# tmp<-ftrOblPairs[ftrOblPairs$Source==ii & ftrOblPairs$Sink==jj,]
# matplot(csDate2mm(tmp$startDateYM), tmp$avgPrice, type='l', lwd=3, col='Blue')
# dev.off()
# }}
# dev.off(which = dev.cur())
# 
# 
# dev.new()
# tmp<-ftrOblPairs[ftrOblPairs$Source=='OTA' & ftrOblPairs$Sink=='BEN',]
# matplot(csDate2mm(tmp$startDateYM), tmp$avgPrice, type='l', lwd=3, col='Blue')
# 
# dev.new()
# tmp<-ftrOblPairs[ftrOblPairs$Source=='BEN' & ftrOblPairs$Sink=='OTA',]
# matplot(csDate2mm(tmp$startDateYM), tmp$avgPrice, type='l', lwd=3, col='Red')
# 
# dev.new()
# tmp<-ftrOblPairs[ftrOblPairs$Source=='OTA' & ftrOblPairs$Sink=='HAY',]
# matplot(csDate2mm(tmp$startDateYM), tmp$avgPrice, type='l', lwd=3, col='Blue')
# 
# 
# 
# ota<-ftrOBL %>% select(auctionYM, AuctionName, StartDate, EndDate, Source, Sink, Price) %>% group_by  
# 
#                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                (auctionYM, StartDate, Source, Sink) %>% summarise(avgPrice = mean(Price))
