# csLoadAnalysisITP
#
# Purpose: Compute monthly seasonal load patterns by participant or groups of participants for regional 'zones'.
#
# Christie Smith  15 September 2020
#
# Inputs: N/A
#
# Outputs: 
#   Produces/displays tables associated with monthly load by zone (eg UNI, CNI, LNI, USI, LSI). 
#   The code develops essentially a matrix of weights for each zone for the 12 months of the year.
#   The weights are ultimately used (in conjunction with another R script) to aggregate benchmark 
#   internal transfer prices into a single price for a financial year.
#   The seasonal patterns in load can differ, depending on participants' load profiles thus affecting the weights of internal transfer prices. 
#
# Requires: -- packages tidyverse and lubridate; data file injection-offtake-all-participants.csv.
#
# Version control: -v2: Typos corrected, added more explanatory comments


library(tidyverse)
library(lubridate)

## Control variables

# All seasonal load patterns are saved to the following single file
fileNameLoad<-paste('seasonalLoad',today(),'-v5.csv', sep='')


## Load data

df<-read.csv("injection-offtake-all-participants.csv", header=TRUE, fileEncoding="UTF-8-BOM")

setwd('H:/My Documents/D3D4/rCode/csLoadOutput')

# Concentrate on offtakes to minimise the memory burden of df
df<-df[df$FlowType=='Offtake',]

# Easier to work with a clean year index
df$cYear<-year(df$CalendarYear)

summary(df)


## Specify parent companies then identify retailers (cf consumers & generators)

#"Unique parent" names
uniParent<-as.character(sort(unique(df$ParentParticipantName)))
generatorNames<-uniParent[is.element(uniParent,c("King Country Energy Ltd","Opunake Hydro Ltd",
								 "New Zealand Wind Farms","Eastland Generation Limited",
								"Lloyd Wensley","Brooklyn Electricity Limited","Awhitu Windfarms Limited","Ngawha Generation Ltd "))];
TranspowerName<-uniParent[uniParent=='Transpower New Zealand Ltd'];
consumerNames<-uniParent[is.element(uniParent,c("New Zealand Steel Ltd","Cold Storage Nelson Ltd","Winstone Pulp International",
		"Norske Skog Tasman Ltd","Pan Pacific Forest Industries Ltd","New Zealand Aluminium Smelters Ltd","The New Zealand Refining Company Limited",
		"Norske Skog Tasman Limited"))] 
integratedNames<-uniParent[is.element(uniParent,c("Contact Energy","Genesis Energy Ltd","Mercury NZ Ltd","Meridian Energy Ltd","TrustPower Ltd"))]
independentNames<-setdiff(uniParent,c(consumerNames,TranspowerName,generatorNames,integratedNames))
independentsExNovaNames<-setdiff(independentNames,"Nova Energy Ltd")

# Check that I've partitioned all the parent-participant names -- should return "character(0)"
setdiff(uniParent,c(TranspowerName,consumerNames,integratedNames,independentNames,generatorNames))

# Compute the load in the 5 'Zones' (Upper North Island, Central North Island, Lower North Island, Upper South Island, Lower South Island)
ld<-c(sum(df$KiloWattHour[df$Zone=='UNI']), sum(df$KiloWattHour[df$Zone=='CNI']) , sum(df$KiloWattHour[df$Zone=='LNI']), sum(df$KiloWattHour[df$Zone=='USI']) , sum(df$KiloWattHour[df$Zone=='LSI']))  
print(rbind(c('UNI', 'CNI', 'LNI', 'USI', 'LSI'), ld, ld/sum(ld)))


## Compute the seasonal pattern for all loads -- broken down by region (UNI, CNI, LNI, USI, LSI). NB: Takes load averages for the years 2017,2018,2019

# NOTE: offt has different output to offtakeAll etc. The weights in offt are specific to the Zone, whereas the others result in matrices of weights summing to 1.
offt<- df %>% select(cYear, Zone, MonthNumber, KiloWattHour, ParentParticipantName) %>% filter(df$cYear>2016, df$cYear<2020, ParentParticipantName %in% c(independentNames,integratedNames)) %>% group_by (Zone,MonthNumber) %>% summarise(totalKWh=sum(KiloWattHour)) %>%mutate(pctKWh=totalKWh/sum(totalKWh)) 
view(offt)
offt %>% select(pctKWh) %>% summarise(sum(pctKWh))


offtakeAll<- df %>% select(cYear, Zone, MonthNumber, KiloWattHour, ParentParticipantName) %>% filter(df$cYear>2016, df$cYear<2020, ParentParticipantName %in% c(integratedNames,independentNames)) %>% group_by (Zone,MonthNumber) %>% summarise(totalKWh=sum(KiloWattHour)) 
offtakeAll<-offtakeAll %>% mutate(pctKWh=totalKWh/sum(offtakeAll$totalKWh))
# Arrange the data in the preferred order
offtakeAll=offtakeAll%>% mutate(zIndex=(Zone=='UNI')*1+(Zone=='CNI')*2+(Zone=='LNI')*3+(Zone=='USI')*4+(Zone=='LSI')*5) %>% arrange(zIndex) 
offtakeAllMat<-t(matrix(offtakeAll$pctKWh,12,5))
view(offtakeAll)
print(offtakeAllMat,digits=2)
sum(offtakeAllMat)

# Load from independents including Nova
offtakeIndependents<- df %>% select(cYear, Zone, MonthNumber, KiloWattHour, ParentParticipantName) %>% filter(df$cYear>2016, df$cYear<2020, ParentParticipantName %in% c(independentNames)) %>% group_by (Zone,MonthNumber) %>% summarise(totalKWh=sum(KiloWattHour)) 
offtakeIndependents<-offtakeIndependents %>% mutate(pctKWh=totalKWh/sum(offtakeIndependents$totalKWh))
offtakeIndependents=offtakeIndependents%>% mutate(zIndex=(Zone=='UNI')*1+(Zone=='CNI')*2+(Zone=='LNI')*3+(Zone=='USI')*4+(Zone=='LSI')*5) %>% arrange(zIndex) 
offtakeIndependentsMat<-t(matrix(offtakeIndependents$pctKWh,12,5))
view(offtakeIndependents)
print(offtakeIndependentsMat,digits=2)
sum(offtakeIndependentsMat)

# Load weights from independents excluding Nova.
offtakeIndependentsExNova<- df %>% select(cYear, Zone, MonthNumber, KiloWattHour, ParentParticipantName) %>% filter(df$cYear>2016, df$cYear<2020, ParentParticipantName %in% independentsExNovaNames) %>% group_by (Zone,MonthNumber) %>% summarise(totalKWh=sum(KiloWattHour)) 
offtakeIndependentsExNova<-offtakeIndependentsExNova %>% mutate(pctKWh=totalKWh/sum(offtakeIndependentsExNova$totalKWh))
offtakeIndependentsExNova=offtakeIndependentsExNova%>% mutate(zIndex=(Zone=='UNI')*1+(Zone=='CNI')*2+(Zone=='LNI')*3+(Zone=='USI')*4+(Zone=='LSI')*5) %>% arrange(zIndex) 
offtakeIndependentsExNovaMat<-t(matrix(offtakeIndependentsExNova$pctKWh,12,5))
view(offtakeIndependentsExNova)
print(offtakeIndependentsExNovaMat,digits=2)
sum(offtakeIndependentsExNovaMat)

# Load weights from integrated retailers
offtakeIntegrated<- df %>% select(cYear, Zone, MonthNumber, KiloWattHour, ParentParticipantName) %>% filter(df$cYear>2016, df$cYear<2020, ParentParticipantName %in% integratedNames) %>% group_by (Zone,MonthNumber) %>% summarise(totalKWh=sum(KiloWattHour)) 
offtakeIntegrated<-offtakeIntegrated %>% mutate(pctKWh=totalKWh/sum(offtakeIntegrated$totalKWh))
offtakeIntegrated=offtakeIntegrated%>% mutate(zIndex=(Zone=='UNI')*1+(Zone=='CNI')*2+(Zone=='LNI')*3+(Zone=='USI')*4+(Zone=='LSI')*5) %>% arrange(zIndex) 
offtakeIntegratedMat<-t(matrix(offtakeIntegrated$pctKWh,12,5))
view(offtakeIntegrated)
print(offtakeIntegratedMat,digits=2)
sum(offtakeIntegratedMat)

# Load weights from Meridian retailers
offtakeMeridian<- df %>% select(cYear, Zone, MonthNumber, KiloWattHour, ParentParticipantName) %>% filter(df$cYear>2016, df$cYear<2020, ParentParticipantName=="Meridian Energy Ltd" ) %>% group_by (Zone,MonthNumber) %>% summarise(totalKWh=sum(KiloWattHour)) 
offtakeMeridian<-offtakeMeridian %>% mutate(pctKWh=totalKWh/sum(offtakeMeridian$totalKWh))
offtakeMeridian=offtakeMeridian%>% mutate(zIndex=(Zone=='UNI')*1+(Zone=='CNI')*2+(Zone=='LNI')*3+(Zone=='USI')*4+(Zone=='LSI')*5) %>% arrange(zIndex) 
offtakeMeridianMat<-t(matrix(offtakeMeridian$pctKWh,12,5))
view(offtakeMeridian)
print(offtakeMeridianMat,digits=2)
sum(offtakeMeridianMat)

# Load weights from Genesis retailers
offtakeGenesis<- df %>% select(cYear, Zone, MonthNumber, KiloWattHour, ParentParticipantName) %>% filter(df$cYear>2016, df$cYear<2020, ParentParticipantName=="Genesis Energy Ltd" ) %>% group_by (Zone,MonthNumber) %>% summarise(totalKWh=sum(KiloWattHour)) 
offtakeGenesis<-offtakeGenesis %>% mutate(pctKWh=totalKWh/sum(offtakeGenesis$totalKWh))
offtakeGenesis=offtakeGenesis%>% mutate(zIndex=(Zone=='UNI')*1+(Zone=='CNI')*2+(Zone=='LNI')*3+(Zone=='USI')*4+(Zone=='LSI')*5) %>% arrange(zIndex) 
offtakeGenesisMat<-t(matrix(offtakeGenesis$pctKWh,12,5))
view(offtakeGenesis)
print(offtakeGenesisMat,digits=2)
sum(offtakeGenesisMat)

# Load weights from Mercury retailers
offtakeMercury<- df %>% select(cYear, Zone, MonthNumber, KiloWattHour, ParentParticipantName) %>% filter(df$cYear>2016, df$cYear<2020, ParentParticipantName=="Mercury NZ Ltd" ) %>% group_by (Zone,MonthNumber) %>% summarise(totalKWh=sum(KiloWattHour)) 
offtakeMercury<-offtakeMercury %>% mutate(pctKWh=totalKWh/sum(offtakeMercury$totalKWh))
offtakeMercury=offtakeMercury%>% mutate(zIndex=(Zone=='UNI')*1+(Zone=='CNI')*2+(Zone=='LNI')*3+(Zone=='USI')*4+(Zone=='LSI')*5) %>% arrange(zIndex) 
offtakeMercuryMat<-t(matrix(offtakeMercury$pctKWh,12,5))
view(offtakeMercury)
print(offtakeMercuryMat,digits=2)
sum(offtakeMercuryMat)

# Load weights from Contact retailers
offtakeContact<- df %>% select(cYear, Zone, MonthNumber, KiloWattHour, ParentParticipantName) %>% filter(df$cYear>2016, df$cYear<2020, ParentParticipantName=="Contact Energy" ) %>% group_by (Zone,MonthNumber) %>% summarise(totalKWh=sum(KiloWattHour)) 
offtakeContact<-offtakeContact %>% mutate(pctKWh=totalKWh/sum(offtakeContact$totalKWh))
offtakeContact=offtakeContact%>% mutate(zIndex=(Zone=='UNI')*1+(Zone=='CNI')*2+(Zone=='LNI')*3+(Zone=='USI')*4+(Zone=='LSI')*5) %>% arrange(zIndex) 
offtakeContactMat<-t(matrix(offtakeContact$pctKWh,12,5))
view(offtakeContact)
print(offtakeContactMat,digits=2)
sum(offtakeContactMat)

# Load weights from Trustpower retailers
offtakeTrustpower<- df %>% select(cYear, Zone, MonthNumber, KiloWattHour, ParentParticipantName) %>% filter(df$cYear>2016, df$cYear<2020, ParentParticipantName=="TrustPower Ltd" ) %>% group_by (Zone,MonthNumber) %>% summarise(totalKWh=sum(KiloWattHour)) 
offtakeTrustpower<-offtakeTrustpower %>% mutate(pctKWh=totalKWh/sum(offtakeTrustpower$totalKWh))
offtakeTrustpower=offtakeTrustpower%>% mutate(zIndex=(Zone=='UNI')*1+(Zone=='CNI')*2+(Zone=='LNI')*3+(Zone=='USI')*4+(Zone=='LSI')*5) %>% arrange(zIndex) 
offtakeTrustpowerMat<-t(matrix(offtakeTrustpower$pctKWh,12,5))
view(offtakeTrustpower)
print(offtakeTrustpowerMat,digits=2)
sum(offtakeTrustpowerMat)


# Consider the differences in weights between the integrated and independent retailers
offtakeIntegratedMat-offtakeIndependentsExNovaMat

# The following confirms that the CNI results are equivalent to offt
a<-c(sum(df$KiloWattHour[df$Zone=='CNI' & df$MonthNumber==1 & df$cYear>2016 & df$cYear<2020 & is.element(df$ParentParticipantName,c(independentNames,integratedNames))]),
sum(df$KiloWattHour[df$Zone=='CNI' & df$MonthNumber==2 & df$cYear>2016 & df$cYear<2020 & is.element(df$ParentParticipantName,c(independentNames,integratedNames))]),
sum(df$KiloWattHour[df$Zone=='CNI' & df$MonthNumber==3 & df$cYear>2016 & df$cYear<2020 & is.element(df$ParentParticipantName,c(independentNames,integratedNames))]),
sum(df$KiloWattHour[df$Zone=='CNI' & df$MonthNumber==4 & df$cYear>2016 & df$cYear<2020 & is.element(df$ParentParticipantName,c(independentNames,integratedNames))]),
sum(df$KiloWattHour[df$Zone=='CNI' & df$MonthNumber==5 & df$cYear>2016 & df$cYear<2020 & is.element(df$ParentParticipantName,c(independentNames,integratedNames))]),
sum(df$KiloWattHour[df$Zone=='CNI' & df$MonthNumber==6 & df$cYear>2016 & df$cYear<2020 & is.element(df$ParentParticipantName,c(independentNames,integratedNames))]),
sum(df$KiloWattHour[df$Zone=='CNI' & df$MonthNumber==7 & df$cYear>2016 & df$cYear<2020 & is.element(df$ParentParticipantName,c(independentNames,integratedNames))]),
sum(df$KiloWattHour[df$Zone=='CNI' & df$MonthNumber==8 & df$cYear>2016 & df$cYear<2020 & is.element(df$ParentParticipantName,c(independentNames,integratedNames))]),
sum(df$KiloWattHour[df$Zone=='CNI' & df$MonthNumber==9 & df$cYear>2016 & df$cYear<2020 & is.element(df$ParentParticipantName,c(independentNames,integratedNames))]),
sum(df$KiloWattHour[df$Zone=='CNI' & df$MonthNumber==10 & df$cYear>2016 & df$cYear<2020 & is.element(df$ParentParticipantName,c(independentNames,integratedNames))]),
sum(df$KiloWattHour[df$Zone=='CNI' & df$MonthNumber==11 & df$cYear>2016 & df$cYear<2020 & is.element(df$ParentParticipantName,c(independentNames,integratedNames))]),
sum(df$KiloWattHour[df$Zone=='CNI' & df$MonthNumber==12 & df$cYear>2016 & df$cYear<2020 & is.element(df$ParentParticipantName,c(independentNames,integratedNames))]))
print('Monthly Load for CNI')
cbind(a/sum(a))



# Define an x-axis sequence
monthIdxs<-matrix(1:12,ncol=5, nrow=12)
legendNames=c('CNI', 'LNI', 'LSI', 'UNI', 'USI')

# Define the data in a clean accessible form -- NOTE that sum(seasonalLoad)=5, because each zone has weights that add to one in offt -- which differs from offtakeAll
seasonalLoad=matrix(offt$pctKWh, ncol=5)
seasonalLoadDf<-data.frame(seasonalLoad,row.names=rbind('Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug','Sep', 'Oct', 'Nov', 'Dec'))
names(seasonalLoadDf)=c(legendNames)
view(offt)

# Plot the load data
dev.new()
#png(file=paste(fileNameLoad, "AllRetailerSeasonalLoad.png", sep=""))
pdf(file=paste(fileNameLoad, "AllRetailerSeasonalLoad.PDF", sep=""))
matplot(monthIdxs, seasonalLoad, lwd=3, xlab='Months (1=Jan ... 12=Dec)', ylab='Seasonal Load (Monthly Percents)', type='l', main='Seasonal Load (All retailers)')
legend(1,0.093, legendNames, col=1:5, fill=1:5)
dev.off()

# Save all-retailer load
print(seasonalLoadDf, digits=2)
write.table('Seasonal Load All Retailers', fileNameLoad, sep=',',append=TRUE)
write.table(seasonalLoadDf, fileNameLoad, sep=',',append=TRUE)

independentSeasonalLoad<-matrix(offtakeIndependents$pctKWh, ncol=5)
independentSeasonalLoadDf<-data.frame(independentSeasonalLoad,row.names=rbind('Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug','Sep', 'Oct', 'Nov', 'Dec'))
names(independentSeasonalLoadDf)<-legendNames

write.table("Seasonal load - Independent retailers including Nova", fileNameLoad, sep=',', append=TRUE)
write.table(independentSeasonalLoadDf, fileNameLoad, sep=',', append=TRUE)

# Plot independents
dev.new()
pdf(file=paste(fileNameLoad, "IndeptSeasonalLoad.pdf", sep=""))
matplot(monthIdxs, independentSeasonalLoad, lwd=3, ylim=c(0.0,0.04), xlab='Months (1=Jan ... 12=Dec)', ylab='Seasonal Load (Monthly Percents)', type='l', main="Seasonal Load (Independent retailers)")
legend(1,0.04, legendNames, col=1:5, fill=1:5)
dev.off()


# Plot difference in load profile between independents and all retailers
dev.new()
pdf(file=paste(fileNameLoad, "AllLessIndeptSeasonalLoadDiff.pdf", sep=""))
matplot(t(offtakeAllMat)-t(offtakeIndependentsMat), type='l', main='Total Seasonal Load less Independent Seasonal Load', lwd=4,xlab='Months (1=Jan ... 12=Dec)', ylab='Difference in seasonal weights')
legend(8,0.0045, legendNames, col=1:5, fill=1:5)
dev.off()


## Load from independents excluding Nova

indeptExNova<-setdiff(independentNames,"Nova Energy Ltd")
offtakeIndeptExNova<- df %>% select(cYear, Zone, MonthNumber, KiloWattHour, ParentParticipantName) %>% filter(df$cYear>2016, df$cYear<2020, ParentParticipantName %in% indeptExNova) %>% group_by (Zone,MonthNumber)  %>% summarise(totalKWh=sum(KiloWattHour)) 
offtakeIndeptExNova<-offtakeIndeptExNova %>% mutate(pctKWh=totalKWh/sum(offtakeIndeptExNova$totalKWh))
offtakeIndeptExNovaMat<-t(matrix(offtakeIndeptExNova$pctKWh, 12, 5))

view(offtakeIndeptExNova)
# Check the following sums to 1
sum(offtakeIndeptExNovaMat)

print.data.frame(offtakeIndeptExNova,digits=2)

indeptExNovaSeasonalLoad<-matrix(offtakeIndeptExNova$pctKWh, ncol=5)
indeptExNovaSeasonalLoadDf<-data.frame(indeptExNovaSeasonalLoad,row.names=rbind('Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug','Sep', 'Oct', 'Nov', 'Dec'))
names(indeptExNovaSeasonalLoadDf)<-legendNames

write.table("Seasonal Load - Independent Retailers excluding Nova", fileNameLoad, sep=',', append=TRUE)
write.table(indeptExNovaSeasonalLoadDf, fileNameLoad, sep=',', append=TRUE)

# Plot independents-ex-Nova
dev.new()
pdf(file=paste(fileNameLoad, "IndeptExNovaSeasonalLoad.pdf", sep=""))
matplot(monthIdxs, indeptExNovaSeasonalLoad, lwd=3, ylim=c(0.0,0.10), xlab='Months (1=Jan ... 12=Dec)', ylab='Seasonal Load (Monthly Percents)', type='l', main="Seasonal Load (Independent retailers ex Nova)")
legend(1,0.093, legendNames, col=1:5, fill=1:5)

# Plot difference in load profile between independents and all retailers
dev.new()
pdf(file=paste(fileNameLoad, "IndeptInclNovaLessIndeptSeasonalLoadDiff.pdf", sep=""))
matplot(independentSeasonalLoad-indeptExNovaSeasonalLoad, type='l', main='Independent-Incl-Nova Seasonal Load \n less Independent-Excl-Nova Seasonal Load', lwd=4,xlab='Months (1=Jan ... 12=Dec)', ylab='Difference in seasonal weights')
legend(9,0.005, legendNames, col=1:5, fill=1:5)

dev.off()


## Load by region for integrated generator-retailers

df %>% select(cYear, Zone, KiloWattHour) %>% filter(df$cYear>2016, df$cYear<2020) %>% group_by (Zone) %>% summarise(totalKWh=sum(KiloWattHour)) %>%mutate(pctZone=totalKWh/sum(totalKWh)) 

Big5<- df %>% select(cYear, Zone, KiloWattHour, ParentParticipantCode) %>% filter(df$cYear>2016, df$cYear<2020, ParentParticipantCode %in% c('MERI', 'CTCT', 'GENE', 'MRPL', 'TRUS')) %>% group_by (ParentParticipantCode, Zone) %>% summarise(totalKWh=sum(KiloWattHour)) %>%mutate(pctKWh=totalKWh/sum(totalKWh)) 
view(Big5)


Contact<- df %>% select(cYear, Zone, KiloWattHour, ParentParticipantCode) %>% filter(df$cYear>2016, df$cYear<2020, ParentParticipantCode %in% 'CTCT') %>% group_by (Zone) %>% summarise(totalKWh=sum(KiloWattHour)) %>%mutate(pctKWh=totalKWh/sum(totalKWh)) 
view(Contact)

Genesis<- df %>% select(cYear, Zone, KiloWattHour, ParentParticipantCode) %>% filter(df$cYear>2016, df$cYear<2020, ParentParticipantCode %in% 'GENE') %>% group_by (Zone) %>% summarise(totalKWh=sum(KiloWattHour)) %>%mutate(pctKWh=totalKWh/sum(totalKWh)) 
view(Genesis)

Mercury<- df %>% select(cYear, Zone, KiloWattHour, ParentParticipantCode) %>% filter(df$cYear>2016, df$cYear<2020, ParentParticipantCode %in% 'MRPL') %>% group_by (Zone) %>% summarise(totalKWh=sum(KiloWattHour)) %>%mutate(pctKWh=totalKWh/sum(totalKWh)) 
view(Mercury)

Meri<- df %>% select(cYear, Zone, KiloWattHour, ParentParticipantCode) %>% filter(df$cYear>2016, df$cYear<2020, ParentParticipantCode %in% 'MERI') %>% group_by (ParentParticipantCode,Zone) %>% summarise(totalKWh=sum(KiloWattHour)) %>%mutate(pctKWh=totalKWh/sum(totalKWh)) 
view(Meri)

Trustpower<- df %>% select(cYear, Zone, KiloWattHour, ParentParticipantCode) %>% filter(df$cYear>2016, df$cYear<2020, ParentParticipantCode %in% 'TRUS') %>% group_by (Zone) %>% summarise(totalKWh=sum(KiloWattHour)) %>%mutate(pctKWh=totalKWh/sum(totalKWh)) 
view(Trustpower)


write.table("Load from Generator-Retailers", fileNameLoad, sep=',', append=TRUE)
write.table(Big5, fileNameLoad, sep=',', append=TRUE)

write.table("Load from Contact", fileNameLoad, sep=',', append=TRUE)
write.table(Contact, fileNameLoad, sep=',', append=TRUE)

write.table("Load from Genesis", fileNameLoad, sep=',', append=TRUE)
write.table(Genesis, fileNameLoad, sep=',', append=TRUE)

write.table("Load from Mercury", fileNameLoad, sep=',', append=TRUE)
write.table(Mercury, fileNameLoad, sep=',', append=TRUE)

write.table("Load from Meri", fileNameLoad, sep=',', append=TRUE)
write.table(Meri, fileNameLoad, sep=',', append=TRUE)

write.table("Load from Trustpower", fileNameLoad, sep=',', append=TRUE)
write.table(Trustpower, fileNameLoad, sep=',', append=TRUE)



## Regional shares of load

ZoneShares<- df %>% select(cYear, Zone, KiloWattHour, ParentParticipantName) %>% 
  filter(df$cYear>2016, df$cYear<2020, ParentParticipantName %in% c(integratedNames,independentNames)) %>% 
  group_by (Zone) %>% summarise(totalKWh=sum(KiloWattHour)) %>%mutate(pctZone=totalKWh/sum(totalKWh)) 
ZoneShares=ZoneShares%>% mutate(zIndex=(Zone=='UNI')*1+(Zone=='CNI')*2+(Zone=='LNI')*3+(Zone=='USI')*4+(Zone=='LSI')*5) %>% arrange(zIndex) 
ZoneShares

# Following confirms the ZoneShares calculations
# sum(df[df$Zone=='UNI' & df$cYear>2016 & df$cYear<2020	,]$KiloWattHour)
# sum(df[df$Zone=='CNI' & df$cYear>2016 & df$cYear<2020	,]$KiloWattHour)
# sum(df[df$Zone=='LNI' & df$cYear>2016 & df$cYear<2020	,]$KiloWattHour)
# sum(df[df$Zone=='USI' & df$cYear>2016 & df$cYear<2020	,]$KiloWattHour)
# sum(df[df$Zone=='LSI' & df$cYear>2016 & df$cYear<2020	,]$KiloWattHour)
# 
# zoneTotsTemp<-c(sum(df[df$Zone=='UNI' & df$cYear>2016 & df$cYear<2020	,]$KiloWattHour),
# sum(df[df$Zone=='CNI' & df$cYear>2016 & df$cYear<2020	,]$KiloWattHour),
# sum(df[df$Zone=='LNI' & df$cYear>2016 & df$cYear<2020	,]$KiloWattHour),
# sum(df[df$Zone=='USI' & df$cYear>2016 & df$cYear<2020	,]$KiloWattHour),
# sum(df[df$Zone=='LSI' & df$cYear>2016 & df$cYear<2020	,]$KiloWattHour))
# 
# zoneTotsTemp/sum(zoneTotsTemp)


write.table("Regional Load", fileNameLoad, sep=',', append=TRUE)
write.table(ZoneShares, fileNameLoad, sep=',', append=TRUE)


# Compute the direct connects share of load
sum(df$KiloWattHour[is.element(df$ParticipantName,consumerNames)])/sum(df$KiloWattHour)


